/*
 * LuaTool native bridge: embeds Lua 5.3 and exposes a "gg" table whose functions are implemented in Java.
 * All strings crossing the JNI boundary are byte[] (Lua strings are binary, JNI modified-UTF-8 would corrupt them).
 */
#include <jni.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "lua/lua.h"
#include "lua/lauxlib.h"
#include "lua/lualib.h"

static JavaVM *g_vm = NULL;
static JNIEnv *g_env = NULL;            /* env of the thread that is inside run() */
static volatile int g_stop = 0;
static volatile int g_exit = 0;

static jclass cObject, cBoolean, cLong, cDouble, cString, cTbl, cNative, cThrowable, cBytes;
static jmethodID mBooleanValue, mLongValue, mDoubleValue, mBooleanOf, mLongOf, mDoubleOf;
static jmethodID mTblCtor, mCallback, mPrint, mToString;
static jfieldID fArr, fKv;

#define MAX_DEPTH 6

/* ------------------------------------------------------------------ marshalling */

static jobject tojava(lua_State *L, JNIEnv *env, int idx, int depth) {
    idx = lua_absindex(L, idx);
    switch (lua_type(L, idx)) {
        case LUA_TBOOLEAN:
            return (*env)->CallStaticObjectMethod(env, cBoolean, mBooleanOf, (jboolean)(lua_toboolean(L, idx) ? JNI_TRUE : JNI_FALSE));
        case LUA_TNUMBER:
            if (lua_isinteger(L, idx))
                return (*env)->CallStaticObjectMethod(env, cLong, mLongOf, (jlong)lua_tointeger(L, idx));
            return (*env)->CallStaticObjectMethod(env, cDouble, mDoubleOf, (jdouble)lua_tonumber(L, idx));
        case LUA_TSTRING: {
            size_t len;
            const char *s = lua_tolstring(L, idx, &len);
            jbyteArray a = (*env)->NewByteArray(env, (jsize)len);
            if (a && len) (*env)->SetByteArrayRegion(env, a, 0, (jsize)len, (const jbyte *)s);
            return a;
        }
        case LUA_TTABLE: {
            if (depth >= MAX_DEPTH) return NULL;
            if (!lua_checkstack(L, 6)) return NULL;
            lua_Integer n = (lua_Integer)lua_rawlen(L, idx);
            jsize kvCount = 0;
            lua_pushnil(L);
            while (lua_next(L, idx)) {
                if (!(lua_type(L, -2) == LUA_TNUMBER && lua_isinteger(L, -2) &&
                      lua_tointeger(L, -2) >= 1 && lua_tointeger(L, -2) <= n))
                    kvCount++;
                lua_pop(L, 1);
            }
            jobjectArray arr = (*env)->NewObjectArray(env, (jsize)n, cObject, NULL);
            jobjectArray kv = (*env)->NewObjectArray(env, kvCount * 2, cObject, NULL);
            if (!arr || !kv) return NULL;
            for (lua_Integer i = 1; i <= n; i++) {
                lua_rawgeti(L, idx, i);
                jobject o = tojava(L, env, -1, depth + 1);
                lua_pop(L, 1);
                if (o) {
                    (*env)->SetObjectArrayElement(env, arr, (jsize)(i - 1), o);
                    (*env)->DeleteLocalRef(env, o);
                }
            }
            jsize k = 0;
            lua_pushnil(L);
            while (lua_next(L, idx)) {
                if (k < kvCount * 2 && !(lua_type(L, -2) == LUA_TNUMBER && lua_isinteger(L, -2) &&
                      lua_tointeger(L, -2) >= 1 && lua_tointeger(L, -2) <= n)) {
                    jobject ko = tojava(L, env, -2, depth + 1);
                    jobject vo = tojava(L, env, -1, depth + 1);
                    if (ko) { (*env)->SetObjectArrayElement(env, kv, k, ko); (*env)->DeleteLocalRef(env, ko); }
                    if (vo) { (*env)->SetObjectArrayElement(env, kv, k + 1, vo); (*env)->DeleteLocalRef(env, vo); }
                    k += 2;
                }
                lua_pop(L, 1);
            }
            jobject t = (*env)->NewObject(env, cTbl, mTblCtor, arr, kv);
            (*env)->DeleteLocalRef(env, arr);
            (*env)->DeleteLocalRef(env, kv);
            return t;
        }
        default:
            return NULL;   /* nil, functions, userdata, threads -> nil */
    }
}

static void pushjava(lua_State *L, JNIEnv *env, jobject o, int depth) {
    if (!o) { lua_pushnil(L); return; }
    if (!lua_checkstack(L, 8)) { lua_pushnil(L); return; }
    if ((*env)->IsInstanceOf(env, o, cBoolean)) {
        lua_pushboolean(L, (*env)->CallBooleanMethod(env, o, mBooleanValue) ? 1 : 0);
    } else if ((*env)->IsInstanceOf(env, o, cLong)) {
        lua_pushinteger(L, (lua_Integer)(*env)->CallLongMethod(env, o, mLongValue));
    } else if ((*env)->IsInstanceOf(env, o, cDouble)) {
        lua_pushnumber(L, (lua_Number)(*env)->CallDoubleMethod(env, o, mDoubleValue));
    } else if ((*env)->IsInstanceOf(env, o, cBytes)) {
        jsize len = (*env)->GetArrayLength(env, (jarray)o);
        jbyte *p = (*env)->GetByteArrayElements(env, (jbyteArray)o, NULL);
        lua_pushlstring(L, (const char *)p, (size_t)len);
        (*env)->ReleaseByteArrayElements(env, (jbyteArray)o, p, JNI_ABORT);
    } else if ((*env)->IsInstanceOf(env, o, cString)) {
        const char *s = (*env)->GetStringUTFChars(env, (jstring)o, NULL);
        lua_pushstring(L, s);
        (*env)->ReleaseStringUTFChars(env, (jstring)o, s);
    } else if (depth < MAX_DEPTH && (*env)->IsInstanceOf(env, o, cTbl)) {
        jobjectArray arr = (jobjectArray)(*env)->GetObjectField(env, o, fArr);
        jobjectArray kv = (jobjectArray)(*env)->GetObjectField(env, o, fKv);
        jsize na = arr ? (*env)->GetArrayLength(env, arr) : 0;
        jsize nk = kv ? (*env)->GetArrayLength(env, kv) : 0;
        lua_createtable(L, na, nk / 2);
        for (jsize i = 0; i < na; i++) {
            jobject e = (*env)->GetObjectArrayElement(env, arr, i);
            pushjava(L, env, e, depth + 1);
            if (e) (*env)->DeleteLocalRef(env, e);
            lua_rawseti(L, -2, (lua_Integer)i + 1);
        }
        for (jsize i = 0; i + 1 < nk; i += 2) {
            jobject ke = (*env)->GetObjectArrayElement(env, kv, i);
            jobject ve = (*env)->GetObjectArrayElement(env, kv, i + 1);
            if (ke) {
                pushjava(L, env, ke, depth + 1);
                pushjava(L, env, ve, depth + 1);
                int kt = lua_type(L, -2);
                int okKey = (kt == LUA_TNUMBER || kt == LUA_TSTRING || kt == LUA_TBOOLEAN);
                if (okKey && kt == LUA_TNUMBER && !lua_isinteger(L, -2)) {
                    lua_Number d = lua_tonumber(L, -2);
                    if (d != d) okKey = 0;   /* NaN is not a valid key */
                }
                if (okKey) lua_rawset(L, -3);
                else lua_pop(L, 2);
            }
            if (ke) (*env)->DeleteLocalRef(env, ke);
            if (ve) (*env)->DeleteLocalRef(env, ve);
        }
        if (arr) (*env)->DeleteLocalRef(env, arr);
        if (kv) (*env)->DeleteLocalRef(env, kv);
    } else {
        lua_pushnil(L);
    }
}

/* Turns a pending Java exception into a message and clears it. */
static void take_exception(JNIEnv *env, char *buf, size_t cap) {
    jthrowable ex = (*env)->ExceptionOccurred(env);
    (*env)->ExceptionClear(env);
    snprintf(buf, cap, "java exception");
    if (ex) {
        jstring s = (jstring)(*env)->CallObjectMethod(env, ex, mToString);
        if ((*env)->ExceptionCheck(env)) {
            (*env)->ExceptionClear(env);
        } else if (s) {
            const char *c = (*env)->GetStringUTFChars(env, s, NULL);
            if (c) { snprintf(buf, cap, "%s", c); (*env)->ReleaseStringUTFChars(env, s, c); }
            (*env)->DeleteLocalRef(env, s);
        }
        (*env)->DeleteLocalRef(env, ex);
    }
}

/* ------------------------------------------------------------------ Lua-visible functions */

static int l_gg(lua_State *L) {
    JNIEnv *env = g_env;
    int id = (int)lua_tointeger(L, lua_upvalueindex(1));
    int n = lua_gettop(L);
    char msg[600];
    int failed = 0;
    if (g_stop) return luaL_error(L, "script stopped");

    jobjectArray args = (*env)->NewObjectArray(env, n, cObject, NULL);
    for (int i = 1; i <= n; i++) {
        jobject o = tojava(L, env, i, 0);
        if (o) {
            (*env)->SetObjectArrayElement(env, args, i - 1, o);
            (*env)->DeleteLocalRef(env, o);
        }
    }
    jobjectArray res = (jobjectArray)(*env)->CallStaticObjectMethod(env, cNative, mCallback, (jint)id, args);
    (*env)->DeleteLocalRef(env, args);
    if ((*env)->ExceptionCheck(env)) {
        take_exception(env, msg, sizeof msg);
        failed = 1;
    }
    if (failed) return luaL_error(L, "%s", msg);
    if (!res) return 0;
    jsize len = (*env)->GetArrayLength(env, res);
    luaL_checkstack(L, len + 4, "too many results");
    for (jsize i = 0; i < len; i++) {
        jobject o = (*env)->GetObjectArrayElement(env, res, i);
        pushjava(L, env, o, 0);
        if (o) (*env)->DeleteLocalRef(env, o);
    }
    (*env)->DeleteLocalRef(env, res);
    return (int)len;
}

static int l_print(lua_State *L) {
    JNIEnv *env = g_env;
    int n = lua_gettop(L);
    size_t cap = 256, used = 0;
    char *buf = (char *)malloc(cap);
    if (!buf) return 0;
    for (int i = 1; i <= n; i++) {
        size_t len;
        const char *s = luaL_tolstring(L, i, &len);   /* honours __tostring */
        size_t need = used + len + 2;
        if (need > cap) {
            while (cap < need) cap *= 2;
            char *nb = (char *)realloc(buf, cap);
            if (!nb) { free(buf); lua_pop(L, 1); return 0; }
            buf = nb;
        }
        if (i > 1) buf[used++] = '\t';
        memcpy(buf + used, s, len);
        used += len;
        lua_pop(L, 1);
    }
    jbyteArray a = (*env)->NewByteArray(env, (jsize)used);
    if (a) {
        if (used) (*env)->SetByteArrayRegion(env, a, 0, (jsize)used, (const jbyte *)buf);
        (*env)->CallStaticVoidMethod(env, cNative, mPrint, a);
        (*env)->DeleteLocalRef(env, a);
        if ((*env)->ExceptionCheck(env)) (*env)->ExceptionClear(env);
    }
    free(buf);
    return 0;
}

/* os.exit() must end only the script, never the app process */
static int l_exit(lua_State *L) {
    g_exit = 1;
    g_stop = 1;
    return luaL_error(L, "script ended (os.exit)");
}

/* returns all its arguments unchanged unless Stop was pressed: then it raises, so pcall cannot swallow Stop */
static int l_stopcheck(lua_State *L) {
    if (g_stop) return luaL_error(L, "script stopped");
    return lua_gettop(L);
}

static void hook(lua_State *L, lua_Debug *ar) {
    (void)ar;
    if (g_stop) luaL_error(L, "script stopped");
}

static int msgh(lua_State *L) {
    const char *m = lua_tostring(L, 1);
    if (m == NULL) {
        if (luaL_callmeta(L, 1, "__tostring") && lua_type(L, -1) == LUA_TSTRING) return 1;
        m = lua_pushfstring(L, "(error object is a %s value)", luaL_typename(L, 1));
    }
    luaL_traceback(L, L, m, 1);
    return 1;
}

/* ------------------------------------------------------------------ JNI entry points */

static jbyteArray tobytes(JNIEnv *env, const char *s, size_t len) {
    jbyteArray a = (*env)->NewByteArray(env, (jsize)len);
    if (a && len) (*env)->SetByteArrayRegion(env, a, 0, (jsize)len, (const jbyte *)s);
    return a;
}

static jclass globalClass(JNIEnv *env, const char *name) {
    jclass c = (*env)->FindClass(env, name);
    if (!c) return NULL;
    jclass g = (jclass)(*env)->NewGlobalRef(env, c);
    (*env)->DeleteLocalRef(env, c);
    return g;
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    (void)reserved;
    g_vm = vm;
    if ((*vm)->GetEnv(vm, (void **)&env, JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;
    cObject = globalClass(env, "java/lang/Object");
    cBoolean = globalClass(env, "java/lang/Boolean");
    cLong = globalClass(env, "java/lang/Long");
    cDouble = globalClass(env, "java/lang/Double");
    cString = globalClass(env, "java/lang/String");
    cThrowable = globalClass(env, "java/lang/Throwable");
    cBytes = globalClass(env, "[B");
    cTbl = globalClass(env, "com/luatool/app/LuaTbl");
    cNative = globalClass(env, "com/luatool/app/NativeLua");
    if (!cObject || !cBoolean || !cLong || !cDouble || !cString || !cThrowable || !cBytes || !cTbl || !cNative) return JNI_ERR;
    mBooleanValue = (*env)->GetMethodID(env, cBoolean, "booleanValue", "()Z");
    mLongValue = (*env)->GetMethodID(env, cLong, "longValue", "()J");
    mDoubleValue = (*env)->GetMethodID(env, cDouble, "doubleValue", "()D");
    mBooleanOf = (*env)->GetStaticMethodID(env, cBoolean, "valueOf", "(Z)Ljava/lang/Boolean;");
    mLongOf = (*env)->GetStaticMethodID(env, cLong, "valueOf", "(J)Ljava/lang/Long;");
    mDoubleOf = (*env)->GetStaticMethodID(env, cDouble, "valueOf", "(D)Ljava/lang/Double;");
    mToString = (*env)->GetMethodID(env, cThrowable, "toString", "()Ljava/lang/String;");
    mTblCtor = (*env)->GetMethodID(env, cTbl, "<init>", "([Ljava/lang/Object;[Ljava/lang/Object;)V");
    fArr = (*env)->GetFieldID(env, cTbl, "arr", "[Ljava/lang/Object;");
    fKv = (*env)->GetFieldID(env, cTbl, "kv", "[Ljava/lang/Object;");
    mCallback = (*env)->GetStaticMethodID(env, cNative, "callback", "(I[Ljava/lang/Object;)[Ljava/lang/Object;");
    mPrint = (*env)->GetStaticMethodID(env, cNative, "print", "([B)V");
    if (!mBooleanValue || !mLongValue || !mDoubleValue || !mBooleanOf || !mLongOf || !mDoubleOf || !mToString ||
        !mTblCtor || !fArr || !fKv || !mCallback || !mPrint) return JNI_ERR;
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL Java_com_luatool_app_NativeLua_stop(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    g_stop = 1;
}

JNIEXPORT jstring JNICALL Java_com_luatool_app_NativeLua_version(JNIEnv *env, jclass cls) {
    (void)cls;
    return (*env)->NewStringUTF(env, LUA_RELEASE);
}

/* returns null on success (or os.exit), otherwise the error message bytes */
JNIEXPORT jbyteArray JNICALL Java_com_luatool_app_NativeLua_run(JNIEnv *env, jclass cls, jbyteArray code, jstring chunk,
                                                                jobjectArray names, jobjectArray consts, jstring prelude) {
    (void)cls;
    jbyteArray result = NULL;
    g_env = env;
    g_stop = 0;
    g_exit = 0;

    lua_State *L = luaL_newstate();
    if (!L) return tobytes(env, "cannot create Lua state (out of memory)", 38);
    luaL_openlibs(L);

    lua_pushcfunction(L, l_print);
    lua_setglobal(L, "print");
    lua_getglobal(L, "os");
    if (lua_istable(L, -1)) {
        lua_pushcfunction(L, l_exit);
        lua_setfield(L, -2, "exit");
    }
    lua_pop(L, 1);

    lua_pushcfunction(L, l_stopcheck);
    lua_setglobal(L, "__lt_check");

    /* gg table */
    lua_newtable(L);
    jsize nn = names ? (*env)->GetArrayLength(env, names) : 0;
    for (jsize i = 0; i < nn; i++) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, names, i);
        const char *c = (*env)->GetStringUTFChars(env, s, NULL);
        lua_pushinteger(L, i);
        lua_pushcclosure(L, l_gg, 1);
        lua_setfield(L, -2, c);
        (*env)->ReleaseStringUTFChars(env, s, c);
        (*env)->DeleteLocalRef(env, s);
    }
    jsize nc = consts ? (*env)->GetArrayLength(env, consts) : 0;
    for (jsize i = 0; i + 1 < nc; i += 2) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, consts, i);
        jobject v = (*env)->GetObjectArrayElement(env, consts, i + 1);
        const char *c = (*env)->GetStringUTFChars(env, s, NULL);
        pushjava(L, env, v, 0);
        lua_setfield(L, -2, c);
        (*env)->ReleaseStringUTFChars(env, s, c);
        (*env)->DeleteLocalRef(env, s);
        if (v) (*env)->DeleteLocalRef(env, v);
    }
    lua_setglobal(L, "gg");

    /* compatibility prelude (loadstring, unpack, setfenv, ...) */
    if (prelude) {
        const char *p = (*env)->GetStringUTFChars(env, prelude, NULL);
        int bad = luaL_dostring(L, p);
        (*env)->ReleaseStringUTFChars(env, prelude, p);
        if (bad) {
            size_t len;
            const char *m = lua_tolstring(L, -1, &len);
            result = tobytes(env, m ? m : "prelude failed", m ? len : 14);
            lua_close(L);
            return result;
        }
    }

    /* load script (source or Lua 5.3 bytecode) */
    jsize clen = (*env)->GetArrayLength(env, code);
    jbyte *cbuf = (*env)->GetByteArrayElements(env, code, NULL);
    const char *cname = (*env)->GetStringUTFChars(env, chunk, NULL);
    int st = luaL_loadbufferx(L, (const char *)cbuf, (size_t)clen, cname, NULL);
    (*env)->ReleaseStringUTFChars(env, chunk, cname);
    (*env)->ReleaseByteArrayElements(env, code, cbuf, JNI_ABORT);
    if (st != LUA_OK) {
        size_t len;
        const char *m = lua_tolstring(L, -1, &len);
        result = tobytes(env, m ? m : "load failed", m ? len : 11);
        lua_close(L);
        return result;
    }

    lua_pushcfunction(L, msgh);
    lua_insert(L, -2);                         /* handler below the chunk */
    lua_sethook(L, hook, LUA_MASKCOUNT, 1000); /* lets Stop interrupt even endless Lua loops */
    st = lua_pcall(L, 0, 0, lua_gettop(L) - 1);
    lua_sethook(L, NULL, 0, 0);
    if (st != LUA_OK && !g_exit) {
        size_t len;
        const char *m = lua_tolstring(L, -1, &len);
        result = tobytes(env, m ? m : "error", m ? len : 5);
    }
    lua_close(L);
    return result;
}
