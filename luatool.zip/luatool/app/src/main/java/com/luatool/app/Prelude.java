package com.luatool.app;

/** Lua code run before every script in the native Lua 5.3 engine: Lua 5.1 / LuaJIT compatibility. */
final class Prelude {
    private Prelude() {}

    static final String LUA =
        "local check = __lt_check; __lt_check = nil\n" +
        "local _pcall, _xpcall, _resume = pcall, xpcall, coroutine.resume\n" +
        "pcall = function(...) return check(_pcall(...)) end\n" +
        "xpcall = function(...) return check(_xpcall(...)) end\n" +
        "coroutine.resume = function(...) return check(_resume(...)) end\n" +
        "loadstring = loadstring or load\n" +
        "unpack = unpack or table.unpack\n" +
        "table.getn = table.getn or function(t) return #t end\n" +
        "table.maxn = table.maxn or function(t) local m = 0 for k in pairs(t) do if type(k) == 'number' and k > m then m = k end end return m end\n" +
        "math.pow = math.pow or function(a, b) return a ^ b end\n" +
        "math.mod = math.mod or math.fmod\n" +
        "math.log10 = math.log10 or function(x) return math.log(x, 10) end\n" +
        "string.gfind = string.gfind or string.gmatch\n" +
        "local function findenv(f)\n" +
        "  local i = 1\n" +
        "  while true do\n" +
        "    local n, v = debug.getupvalue(f, i)\n" +
        "    if n == nil then return nil end\n" +
        "    if n == '_ENV' then return i, v end\n" +
        "    i = i + 1\n" +
        "  end\n" +
        "end\n" +
        "getfenv = getfenv or function(f)\n" +
        "  if type(f) == 'function' then\n" +
        "    local i, v = findenv(f)\n" +
        "    if i then return v end\n" +
        "  end\n" +
        "  return _G\n" +
        "end\n" +
        "setfenv = setfenv or function(f, env)\n" +
        "  if type(f) == 'function' then\n" +
        "    local i = findenv(f)\n" +
        "    if i then debug.upvaluejoin(f, i, function() return env end, 1) end\n" +
        "  end\n" +
        "  return f\n" +
        "end\n" +
        "if not bit and bit32 then\n" +
        "  local function tobit(x) x = x % 4294967296 if x >= 2147483648 then x = x - 4294967296 end return x end\n" +
        "  bit = {\n" +
        "    tobit = tobit,\n" +
        "    band = function(...) return tobit(bit32.band(...)) end,\n" +
        "    bor = function(...) return tobit(bit32.bor(...)) end,\n" +
        "    bxor = function(...) return tobit(bit32.bxor(...)) end,\n" +
        "    bnot = function(x) return tobit(bit32.bnot(x)) end,\n" +
        "    lshift = function(x, n) return tobit(bit32.lshift(x, n)) end,\n" +
        "    rshift = function(x, n) return tobit(bit32.rshift(x, n)) end,\n" +
        "    arshift = function(x, n) return tobit(bit32.arshift(x, n)) end,\n" +
        "    rol = function(x, n) return tobit(bit32.lrotate(x, n)) end,\n" +
        "    ror = function(x, n) return tobit(bit32.rrotate(x, n)) end,\n" +
        "    tohex = function(x, n) n = n or 8 return string.format('%0' .. n .. 'x', bit32.band(x, 0xFFFFFFFF)):sub(-n) end,\n" +
        "  }\n" +
        "end\n";
}
