package com.luatool.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/** The GameGuardian-style "gg" API for the native Lua 5.3 engine. Values are plain Java objects (see LuaTbl / NativeLua). */
final class GgNative implements NativeLua.Host {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    interface Fn { Object[] call(Object[] a) throws Exception; }

    private static final ArrayList<String> NAMES = new ArrayList<>();
    private static final ArrayList<Fn> FNS = new ArrayList<>();
    private final File script;

    GgNative(File script) { this.script = script; }

    static String[] names() { return NAMES.toArray(new String[0]); }

    // ---------- NativeLua.Host ----------

    @Override public Object[] call(int id, Object[] args) throws Exception {
        Session.check();
        try {
            return FNS.get(id).call(args);
        } catch (MemEngine.Cancelled e) {
            throw new RuntimeException("script stopped");
        } catch (InterruptedException e) {
            throw new RuntimeException("script stopped");
        }
    }

    @Override public void print(byte[] line) {
        String s = new String(line, UTF8);
        for (String l : s.split("\n", -1)) AppLog.add(l);
    }

    // ---------- value helpers ----------

    private static Object arg(Object[] a, int i) { return i < a.length ? a[i] : null; }

    static String str(Object o) {
        if (o == null) return null;
        if (o instanceof byte[]) return new String((byte[]) o, UTF8);
        return String.valueOf(o);
    }

    private static long lng(Object o, long def) {
        if (o == null) return def;
        if (o instanceof Long) return (Long) o;
        if (o instanceof Double) return (long) (double) (Double) o;
        try {
            String s = str(o).trim();
            try { return Long.parseLong(s); } catch (NumberFormatException e) { return (long) Double.parseDouble(s); }
        } catch (Exception e) {
            return def;
        }
    }

    private static boolean bool(Object o) {
        return o != null && !(o instanceof Boolean && !((Boolean) o));
    }

    private static Object norm(Object o) {
        if (o instanceof String) return ((String) o).getBytes(UTF8);
        if (o instanceof Integer) return Long.valueOf((Integer) o);
        if (o instanceof Float) return Double.valueOf((Float) o);
        return o;
    }

    private static LuaTbl tbl(Object o, String fn) {
        if (o instanceof LuaTbl) return (LuaTbl) o;
        throw new IllegalArgumentException("gg." + fn + ": table expected");
    }

    private static Object[] none() { return null; }
    private static Object[] one(Object v) { return new Object[]{norm(v)}; }

    private static String[] strList(LuaTbl t) {
        String[] out = new String[t.length()];
        for (int i = 0; i < out.length; i++) out[i] = str(t.get(i + 1));
        return out;
    }

    private static MemEngine eng() {
        MemEngine e = Session.engine;
        if (e == null) throw new IllegalStateException("no process selected");
        return e;
    }

    private static Object valueOf(MemEngine e, long addr, int type) {
        return e.readValue(addr, type);
    }

    /** number or numeric string -> {double, long} */
    private static double[] numParts(Object v) {
        if (v instanceof Long) return new double[]{(Long) v, 0};
        if (v instanceof Double) return new double[]{(Double) v, 0};
        String s = str(v);
        if (s == null) throw new IllegalArgumentException("value is not a number");
        return new double[]{Double.parseDouble(s.trim()), 0};
    }

    private static boolean write(MemEngine e, long addr, int type, Object v) {
        long l;
        double d;
        if (v instanceof Long) { l = (Long) v; d = l; }
        else if (v instanceof Double) { d = (Double) v; l = (long) d; }
        else {
            String s = str(v);
            if (s == null) throw new IllegalArgumentException("value is not a number");
            s = s.trim();
            try { l = Long.parseLong(s); d = l; } catch (NumberFormatException ex) { d = Double.parseDouble(s); l = (long) d; }
        }
        return e.writeNumber(addr, type, d, l);
    }

    private static LuaTbl row(MemEngine e, long addr, int type) {
        Object v = valueOf(e, addr, type);
        if (v == null) return null;
        return LuaTbl.map("address", addr, "value", v, "flags", (long) type);
    }

    private static void reg(String name, Fn f) {
        NAMES.add(name);
        FNS.add(f);
    }

    private static void doSearch(Object[] a, boolean refine) {
        MemEngine e = eng();
        String text = str(arg(a, 0));
        if (text == null) throw new IllegalArgumentException("search value missing");
        int type = (int) lng(arg(a, 1), MemEngine.T_DWORD);
        int sign = (int) lng(arg(a, 3), MemEngine.SIGN_EQUAL);
        if (type == 127) throw new IllegalArgumentException("TYPE_AUTO is not supported - use TYPE_DWORD, TYPE_FLOAT, ...");
        text = text.trim();
        if (text.indexOf(';') < 0 && text.length() > 1) {       // "100D", "1.5F", "0~255B"
            char last = text.charAt(text.length() - 1), prev = text.charAt(text.length() - 2);
            int lt = MemEngine.typeFromLetter(last);
            if (lt > 0 && (Character.isDigit(prev) || prev == '.')) {
                type = lt;
                text = text.substring(0, text.length() - 1);
            }
        }
        long t0 = System.currentTimeMillis();
        e.progress = new MemEngine.Progress() {
            @Override public void onProgress(int pct) {
                AppLog.add("Searching... " + pct + "%");
                UiBridge.toast("Searching... " + pct + "%", true);
            }
        };
        int n;
        try {
            if (refine) {
                n = e.refine(text, type, sign);
            } else {
                long from = lng(arg(a, 4), 0);
                long to = lng(arg(a, 5), -1);
                int limit = (int) lng(arg(a, 6), 0);
                long hi = to < 0 ? Long.MAX_VALUE : to;
                if (text.indexOf(';') >= 0) n = e.searchGroup(text, type, from, hi, limit);
                else n = e.search(text, type, sign, from, hi, limit);
            }
        } finally {
            e.progress = null;
        }
        AppLog.add((refine ? "refine '" : "search '") + text + "': " + n + " results ("
                + (System.currentTimeMillis() - t0) / 1000.0 + " s)");
    }

    // ---------- registration ----------

    static {
        // ----- UI -----
        reg("alert", new Fn() { public Object[] call(Object[] a) {
            String text = str(arg(a, 0));
            String b1 = arg(a, 1) == null ? null : str(a[1]);
            String b2 = arg(a, 2) == null ? null : str(a[2]);
            String b3 = arg(a, 3) == null ? null : str(a[3]);
            try {
                return one((long) UiBridge.alert(text, b1, b2, b3));
            } catch (RuntimeException e) {
                if (Session.stopRequested) throw e;
                AppLog.add("(popup unavailable: " + e.getMessage() + ")  " + text);
                UiBridge.toast(text, false);
                return one(0L);
            }
        }});
        reg("toast", new Fn() { public Object[] call(Object[] a) {
            UiBridge.toast(str(arg(a, 0)), bool(arg(a, 1)));
            return none();
        }});
        reg("choice", new Fn() { public Object[] call(Object[] a) {
            String[] items = strList(tbl(arg(a, 0), "choice"));
            int sel = (int) lng(arg(a, 1), 0) - 1;
            String msg = arg(a, 2) == null ? null : str(a[2]);
            int r = UiBridge.choice(items, sel, msg);
            return r < 0 ? new Object[]{null} : one((long) (r + 1));
        }});
        reg("multiChoice", new Fn() { public Object[] call(Object[] a) {
            String[] items = strList(tbl(arg(a, 0), "multiChoice"));
            boolean[] checked = new boolean[items.length];
            if (arg(a, 1) instanceof LuaTbl) {
                LuaTbl sel = (LuaTbl) a[1];
                for (int i = 0; i < items.length; i++) checked[i] = bool(sel.getAny(Long.valueOf(i + 1)));
            }
            String msg = arg(a, 2) == null ? null : str(a[2]);
            boolean[] r = UiBridge.multiChoice(items, checked, msg);
            if (r == null) return new Object[]{null};
            ArrayList<Object> kv = new ArrayList<>();
            for (int i = 0; i < r.length; i++) if (r[i]) { kv.add(Long.valueOf(i + 1)); kv.add(Boolean.TRUE); }
            return new Object[]{new LuaTbl(null, kv.toArray())};
        }});
        reg("prompt", new Fn() { public Object[] call(Object[] a) {
            LuaTbl prompts = tbl(arg(a, 0), "prompt");
            LuaTbl defs = arg(a, 1) instanceof LuaTbl ? (LuaTbl) a[1] : LuaTbl.list(new ArrayList<Object>());
            LuaTbl types = arg(a, 2) instanceof LuaTbl ? (LuaTbl) a[2] : LuaTbl.list(new ArrayList<Object>());
            List<Object> keys = prompts.keys();
            int n = keys.size();
            String[] labels = new String[n], dv = new String[n], ty = new String[n];
            for (int i = 0; i < n; i++) {
                Object k = keys.get(i);
                labels[i] = str(prompts.getAny(k));
                Object d = defs.getAny(k);
                dv[i] = d == null ? "" : str(d);
                Object t = types.getAny(k);
                ty[i] = t == null ? "text" : str(t);
            }
            Object[] r = UiBridge.prompt(labels, dv, ty);
            if (r == null) return new Object[]{null};
            ArrayList<Object> arr = new ArrayList<>();
            ArrayList<Object> kv = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                Object v;
                if (r[i] instanceof Boolean) v = r[i];
                else if ("number".equals(ty[i])) {
                    try {
                        double d = Double.parseDouble(((String) r[i]).trim());
                        v = (d == Math.rint(d) && Math.abs(d) < 9e15) ? (Object) Long.valueOf((long) d) : (Object) Double.valueOf(d);
                    } catch (NumberFormatException ex) { v = null; }
                } else v = norm(r[i]);
                Object k = keys.get(i);
                if (k instanceof Long && (Long) k == arr.size() + 1 && v != null) arr.add(v);
                else if (v != null) { kv.add(k); kv.add(v); }
            }
            return new Object[]{new LuaTbl(arr.toArray(), kv.toArray())};
        }});
        reg("sleep", new Fn() { public Object[] call(Object[] a) throws Exception {
            long end = System.currentTimeMillis() + lng(arg(a, 0), 0);
            while (true) {
                Session.check();
                long left = end - System.currentTimeMillis();
                if (left <= 0) break;
                Thread.sleep(Math.min(left, 50));
            }
            return none();
        }});
        reg("isVisible", new Fn() { public Object[] call(Object[] a) { return one(OverlayService.panelVisible()); }});
        reg("setVisible", new Fn() { public Object[] call(Object[] a) { OverlayService.setPanelVisible(bool(arg(a, 0))); return none(); }});
        reg("showUiButton", new Fn() { public Object[] call(Object[] a) { OverlayService.setBubbleVisible(true); return none(); }});
        reg("hideUiButton", new Fn() { public Object[] call(Object[] a) { OverlayService.setBubbleVisible(false); return none(); }});
        reg("isClickedUiButton", new Fn() { public Object[] call(Object[] a) {
            Session.lastClickPoll = System.currentTimeMillis();
            boolean c = Session.clicked;
            Session.clicked = false;
            return one(c);
        }});
        reg("copyText", new Fn() { public Object[] call(Object[] a) {
            final Context c = Session.app;
            final String text = str(arg(a, 0));
            if (c != null) UiBridge.main.post(new Runnable() { public void run() {
                try {
                    ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("lua", text));
                } catch (Throwable ignored) {}
            }});
            return one(true);
        }});

        // ----- misc / compatibility -----
        reg("getFile", new Fn() { public Object[] call(Object[] a) {
            File f = Session.scriptFile;
            return one(f == null ? "" : f.getAbsolutePath());
        }});
        reg("skipRestoreState", new Fn() { public Object[] call(Object[] a) { return none(); }});
        reg("require", new Fn() { public Object[] call(Object[] a) { return one(true); }});
        reg("getLocale", new Fn() { public Object[] call(Object[] a) { return one("en"); }});
        reg("getSpeed", new Fn() { public Object[] call(Object[] a) { return one(1.0); }});
        reg("setSpeed", new Fn() { public Object[] call(Object[] a) { return one(true); }});
        reg("isPackageInstalled", new Fn() { public Object[] call(Object[] a) { return one(false); }});
        reg("gotoAddress", new Fn() { public Object[] call(Object[] a) { return none(); }});
        reg("getListItems", new Fn() { public Object[] call(Object[] a) { return one(LuaTbl.list(new ArrayList<Object>())); }});
        reg("getSelectedResults", new Fn() { public Object[] call(Object[] a) { return one(LuaTbl.list(new ArrayList<Object>())); }});
        reg("getSelectedElements", new Fn() { public Object[] call(Object[] a) { return one(LuaTbl.list(new ArrayList<Object>())); }});
        reg("getSelectedListItems", new Fn() { public Object[] call(Object[] a) { return one(LuaTbl.list(new ArrayList<Object>())); }});
        reg("searchFuzzy", new Fn() { public Object[] call(Object[] a) { throw new UnsupportedOperationException("gg.searchFuzzy is not supported yet"); }});
        reg("startFuzzy", new Fn() { public Object[] call(Object[] a) { throw new UnsupportedOperationException("gg.startFuzzy is not supported yet"); }});

        // ----- target -----
        reg("getTargetInfo", new Fn() { public Object[] call(Object[] a) {
            ProcessInfo p = Session.target;
            if (p == null) return new Object[]{null};
            return one(LuaTbl.map("pid", (long) p.pid, "processName", norm(p.name), "packageName", norm(p.name), "label", norm(p.name)));
        }});
        reg("getTargetPackage", new Fn() { public Object[] call(Object[] a) {
            ProcessInfo p = Session.target;
            return p == null ? new Object[]{null} : one(p.name);
        }});
        reg("processPause", new Fn() { public Object[] call(Object[] a) {
            ProcessInfo p = Session.target;
            if (p != null && p.pid != android.os.Process.myPid()) android.os.Process.sendSignal(p.pid, 19);
            return one(true);
        }});
        reg("processResume", new Fn() { public Object[] call(Object[] a) {
            ProcessInfo p = Session.target;
            if (p != null && p.pid != android.os.Process.myPid()) android.os.Process.sendSignal(p.pid, 18);
            return one(true);
        }});

        // ----- ranges -----
        reg("setRanges", new Fn() { public Object[] call(Object[] a) {
            eng().ranges = (int) lng(arg(a, 0), MemEngine.DEFAULT_RANGES);
            return none();
        }});
        reg("getRanges", new Fn() { public Object[] call(Object[] a) { return one((long) eng().ranges); }});
        reg("getRangesList", new Fn() { public Object[] call(Object[] a) {
            String filter = arg(a, 0) == null ? "" : str(a[0]);
            List<MemEngine.Region> rs = eng().regions(MemEngine.R_ALL, 0, Long.MAX_VALUE, false);
            ArrayList<Object> out = new ArrayList<>();
            for (MemEngine.Region r : rs) {
                if (!filter.isEmpty() && !r.path.contains(filter)) continue;
                out.add(LuaTbl.map("start", r.start, "end", r.end, "type", norm(r.perms), "name", norm(r.path),
                        "internalName", norm(r.path), "state", norm("O")));
            }
            return one(LuaTbl.list(out));
        }});

        // ----- search / results -----
        reg("searchNumber", new Fn() { public Object[] call(Object[] a) { doSearch(a, false); return none(); }});
        reg("refineNumber", new Fn() { public Object[] call(Object[] a) { doSearch(a, true); return none(); }});
        reg("clearResults", new Fn() { public Object[] call(Object[] a) { eng().clearResults(); return none(); }});
        Fn count = new Fn() { public Object[] call(Object[] a) { return one((long) eng().count()); }};
        reg("getResultsCount", count);
        reg("getResultCount", count);
        reg("getResults", new Fn() { public Object[] call(Object[] a) {
            MemEngine e = eng();
            int cnt = (int) lng(arg(a, 0), 100);
            int skip = (int) lng(arg(a, 1), 0);
            boolean hasMin = arg(a, 2) != null, hasMax = arg(a, 3) != null, hasType = arg(a, 6) != null;
            boolean hasVMin = arg(a, 4) != null, hasVMax = arg(a, 5) != null;
            long amin = hasMin ? lng(a[2], 0) : 0, amax = hasMax ? lng(a[3], Long.MAX_VALUE) : Long.MAX_VALUE;
            double vmin = hasVMin ? numParts(a[4])[0] : 0, vmax = hasVMax ? numParts(a[5])[0] : 0;
            int type = hasType ? (int) lng(a[6], 0) : 0;
            ArrayList<Object> out = new ArrayList<>();
            for (int i = Math.max(0, skip); i < e.count() && out.size() < cnt; i++) {
                long addr = e.addrAt(i);
                int t = e.typeAt(i);
                if (addr < amin || addr > amax) continue;
                if (hasType && (t & type) == 0) continue;
                LuaTbl r = row(e, addr, t);
                if (r == null) continue;
                if (hasVMin || hasVMax) {
                    Object v = r.get("value");
                    double dv = v instanceof Long ? (Long) v : (Double) v;
                    if (hasVMin && dv < vmin) continue;
                    if (hasVMax && dv > vmax) continue;
                }
                out.add(r);
            }
            return one(LuaTbl.list(out));
        }});
        reg("editAll", new Fn() { public Object[] call(Object[] a) {
            MemEngine e = eng();
            int type = (int) lng(arg(a, 1), MemEngine.T_DWORD);
            long ok = 0;
            for (int i = 0; i < e.count(); i++) {
                if ((i & 0x3FF) == 0) Session.check();
                if (write(e, e.addrAt(i), type, arg(a, 0))) ok++;
            }
            AppLog.add("editAll: wrote " + ok + " of " + e.count());
            return one(ok);
        }});
        reg("getValues", new Fn() { public Object[] call(Object[] a) {
            MemEngine e = eng();
            LuaTbl in = tbl(arg(a, 0), "getValues");
            ArrayList<Object> out = new ArrayList<>();
            for (int i = 1; i <= in.length(); i++) {
                LuaTbl it = tbl(in.get(i), "getValues");
                long addr = lng(it.get("address"), 0);
                int type = (int) lng(it.get("flags"), MemEngine.T_DWORD);
                LuaTbl r = row(e, addr, type);
                out.add(r != null ? r : LuaTbl.map("address", addr, "flags", (long) type));
            }
            return one(LuaTbl.list(out));
        }});
        reg("setValues", new Fn() { public Object[] call(Object[] a) {
            MemEngine e = eng();
            LuaTbl in = tbl(arg(a, 0), "setValues");
            boolean all = true;
            for (int i = 1; i <= in.length(); i++) {
                LuaTbl it = tbl(in.get(i), "setValues");
                if (!write(e, lng(it.get("address"), 0), (int) lng(it.get("flags"), MemEngine.T_DWORD), it.get("value"))) all = false;
            }
            return one(all);
        }});
        reg("loadResults", new Fn() { public Object[] call(Object[] a) {
            MemEngine e = eng();
            LuaTbl in = tbl(arg(a, 0), "loadResults");
            int n = in.length();
            long[] addrs = new long[n];
            int[] types = new int[n];
            int k = 0;
            for (int i = 1; i <= n; i++) {
                Object o = in.get(i);
                if (!(o instanceof LuaTbl)) continue;
                LuaTbl it = (LuaTbl) o;
                addrs[k] = lng(it.get("address"), 0);
                types[k] = (int) lng(it.get("flags"), MemEngine.T_DWORD);
                k++;
            }
            e.loadResults(addrs, types, k);
            return one(true);
        }});

        // ----- freeze -----
        reg("addListItems", new Fn() { public Object[] call(Object[] a) {
            MemEngine e = eng();
            LuaTbl in = tbl(arg(a, 0), "addListItems");
            for (int i = 1; i <= in.length(); i++) {
                Object o = in.get(i);
                if (!(o instanceof LuaTbl)) continue;
                LuaTbl it = (LuaTbl) o;
                if (!bool(it.get("freeze"))) continue;
                Object v = it.get("value");
                if (v == null) continue;
                int type = (int) lng(it.get("flags"), MemEngine.T_DWORD);
                double[] p = numParts(v);
                long l = v instanceof Long ? (Long) v : (long) p[0];
                e.freeze(lng(it.get("address"), 0), type, p[0], l);
            }
            return one(true);
        }});
        reg("removeListItems", new Fn() { public Object[] call(Object[] a) {
            MemEngine e = eng();
            LuaTbl in = tbl(arg(a, 0), "removeListItems");
            for (int i = 1; i <= in.length(); i++) {
                Object o = in.get(i);
                if (o instanceof LuaTbl) e.unfreeze(lng(((LuaTbl) o).get("address"), 0));
            }
            return one(true);
        }});
        reg("clearList", new Fn() { public Object[] call(Object[] a) { eng().clearFreeze(); return none(); }});
    }

    // ---------- constants ----------

    static Object[] constants() {
        ArrayList<Object> c = new ArrayList<>();
        Object[][] longs = {
            {"TYPE_BYTE", 1L}, {"TYPE_WORD", 2L}, {"TYPE_DWORD", 4L}, {"TYPE_XOR", 8L}, {"TYPE_FLOAT", 16L},
            {"TYPE_QWORD", 32L}, {"TYPE_DOUBLE", 64L}, {"TYPE_AUTO", 127L},
            {"REGION_C_HEAP", (long) MemEngine.R_C_HEAP}, {"REGION_JAVA_HEAP", (long) MemEngine.R_JAVA_HEAP},
            {"REGION_C_ALLOC", (long) MemEngine.R_C_ALLOC}, {"REGION_C_DATA", (long) MemEngine.R_C_DATA},
            {"REGION_C_BSS", (long) MemEngine.R_C_BSS}, {"REGION_ANONYMOUS", (long) MemEngine.R_ANON},
            {"REGION_STACK", (long) MemEngine.R_STACK}, {"REGION_ASHMEM", (long) MemEngine.R_ASHMEM},
            {"REGION_JAVA", (long) MemEngine.R_JAVA}, {"REGION_CODE_APP", (long) MemEngine.R_CODE_APP},
            {"REGION_OTHER", (long) MemEngine.R_OTHER}, {"REGION_ALL", -1L},
            {"SIGN_EQUAL", (long) MemEngine.SIGN_EQUAL}, {"SIGN_NOT_EQUAL", (long) MemEngine.SIGN_NOT_EQUAL},
            {"SIGN_GREATER_OR_EQUAL", (long) MemEngine.SIGN_GREATER_OR_EQUAL},
            {"SIGN_LESS_OR_EQUAL", (long) MemEngine.SIGN_LESS_OR_EQUAL},
            {"FREEZE_NORMAL", 0L}, {"FREEZE_MAY_INCREASE", 1L}, {"FREEZE_MAY_DECREASE", 2L}, {"FREEZE_IN_RANGE", 3L},
            {"LOAD_APPEND", 1L}, {"LOAD_VALUES", 2L}, {"LOAD_VALUES_FREEZE", 3L}, {"SAVE_AS_TEXT", 1L},
            {"BUILD", 1L},
        };
        for (Object[] kv : longs) { c.add(kv[0]); c.add(kv[1]); }
        c.add("VERSION"); c.add("LuaTool 1.0".getBytes(UTF8));
        Context app = Session.app;
        if (app != null) {
            c.add("FILES_DIR"); c.add(app.getFilesDir().getAbsolutePath().getBytes(UTF8));
            c.add("TMP_PATH"); c.add(app.getCacheDir().getAbsolutePath().getBytes(UTF8));
        }
        try {
            c.add("EXT_STORAGE"); c.add(Environment.getExternalStorageDirectory().getAbsolutePath().getBytes(UTF8));
        } catch (Throwable ignored) {
            c.remove(c.size() - 1);
        }
        return c.toArray();
    }
}
