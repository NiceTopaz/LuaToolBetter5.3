package com.luatool.app;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaValue;

import java.io.ByteArrayInputStream;

/** Loads script source or (Lua 5.2) bytecode, with clear errors for formats this engine cannot run. */
final class ScriptLoader {
    private ScriptLoader() {}

    /** @return -1 = not bytecode (source text), -2 = LuaJIT bytecode, else the Lua version byte (0x51, 0x52, 0x53, 0x54...). */
    static int bytecodeVersion(byte[] d) {
        if (d.length < 5 || d[0] != 0x1B || d[1] != 'L') return -1;
        if (d[2] == 'J') return -2;
        if (d[2] != 'u' || d[3] != 'a') return -1;
        return d[4] & 0xFF;
    }

    static String versionName(int v) {
        if (v == -2) return "LuaJIT";
        if (v >= 0x51 && v <= 0x54) return "Lua " + (v >> 4) + "." + (v & 0xF);
        return "an unknown Lua version (0x" + Integer.toHexString(v) + ")";
    }

    static String headerHex(byte[] d) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(8, d.length); i++) sb.append(String.format("%02x ", d[i] & 0xFF));
        return sb.toString().trim();
    }

    /** @return null if loadable, else a human readable reason. */
    static String unsupportedBytecode(byte[] d) {
        if (d.length < 5 || d[0] != 0x1B || d[1] != 'L') return null;
        if (d[2] == 'J') return "This is LuaJIT bytecode. LuaTool runs Lua 5.2 only.";
        if (d[2] != 'u' || d[3] != 'a') return null;
        switch (d[4] & 0xFF) {
            case 0x52: return null;   // Lua 5.2 - LuaJ can load it
            case 0x51: return "This is precompiled Lua 5.1 bytecode (luac). LuaTool runs Lua 5.2 source or 5.2 bytecode only.";
            case 0x53: return "This is precompiled Lua 5.3 bytecode (luac / 'encrypted' by a tool). LuaTool's engine is Lua 5.2 and cannot run it - it needs a native Lua 5.3 engine.";
            case 0x54: return "This is precompiled Lua 5.4 bytecode. LuaTool's engine is Lua 5.2 and cannot run it.";
            default: return "Unknown precompiled Lua bytecode (version byte 0x" + Integer.toHexString(d[4] & 0xFF) + ").";
        }
    }

    static LuaValue load(Globals g, byte[] data, String name) {
        String bad = unsupportedBytecode(data);
        if (bad != null) throw new LuaError(bad);
        if (data.length > 4 && data[0] == 0x1B) {
            return g.load(new ByteArrayInputStream(data), "=" + name, "b", g);
        }
        String src;
        try { src = new String(data, "UTF-8"); } catch (Exception e) { throw new LuaError("cannot decode script"); }
        if (src.startsWith("\uFEFF")) src = src.substring(1);
        if (src.startsWith("#")) src = "--" + src;     // shebang line
        return g.load(src, "@" + name);
    }
}
