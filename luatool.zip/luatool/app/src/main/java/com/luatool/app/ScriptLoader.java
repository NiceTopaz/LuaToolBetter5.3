package com.luatool.app;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaValue;

import java.io.ByteArrayInputStream;

/** Loads script source or (Lua 5.2) bytecode, with clear errors for formats this engine cannot run. */
final class ScriptLoader {
    private ScriptLoader() {}

    /** @return null if loadable, else a human readable reason. */
    static String unsupportedBytecode(byte[] d) {
        if (d.length < 5 || d[0] != 0x1B || d[1] != 'L') return null;
        if (d[2] == 'J') return "This is LuaJIT bytecode. LuaTool runs Lua 5.2 only.";
        if (d[2] != 'u' || d[3] != 'a') return null;
        switch (d[4] & 0xFF) {
            case 0x52: return null;   // Lua 5.2 - LuaJ can load it
            case 0x51: return "This is precompiled Lua 5.1 bytecode (luac). LuaTool runs Lua 5.2 source or 5.2 bytecode only.";
            case 0x53: return "This is precompiled Lua 5.3 bytecode (luac / 'encrypted' by a tool). LuaTool's engine is Lua 5.2 and cannot run it - it needs a native Lua 5.3 engine.";
            case 0x54: return "This is precompiled Lua 5.4 bytecode. LuaTool's engine is Lua 5.2 and cannot run it.";
            default: return "Unknown precompiled Lua bytecode (version byte 0x" + Integer.toHexString(d[4] & 0xFF) + ").";
        }
    }

    static LuaValue load(Globals g, byte[] data, String name) {
        String bad = unsupportedBytecode(data);
        if (bad != null) throw new LuaError(bad);
        if (data.length > 4 && data[0] == 0x1B) {
            return g.load(new ByteArrayInputStream(data), "=" + name, "b", g);
        }
        String src;
        try { src = new String(data, "UTF-8"); } catch (Exception e) { throw new LuaError("cannot decode script"); }
        if (src.startsWith("\uFEFF")) src = src.substring(1);
        if (src.startsWith("#")) src = "--" + src;     // shebang line
        return g.load(src, "@" + name);
    }
}
